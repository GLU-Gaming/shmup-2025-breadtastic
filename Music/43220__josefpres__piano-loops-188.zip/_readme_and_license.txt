Pack downloaded from Freesound
----------------------------------------

"Piano loops 188"

This Pack of sounds contains sounds by the following user:
 - josefpres ( https://freesound.org/people/josefpres/ )

You can find this pack online at: https://freesound.org/people/josefpres/packs/43220/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this Pack
-------------------

  * 797754__josefpres__piano-loops-188-octave-short-loop-120-bpm.wav.wav
    * url: https://freesound.org/s/797754/
    * license: Creative Commons 0
  * 797731__josefpres__piano-loops-188-octave-down-short-loop-120-bpm.wav.wav
    * url: https://freesound.org/s/797731/
    * license: Creative Commons 0


